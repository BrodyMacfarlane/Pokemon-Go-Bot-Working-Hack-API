# Credits to Tejado and all the other wonderful developers who worked tirelessly on this project

# Don't use this bot while signed in with your phone -TomTheBotter

import os
import re
import json
import struct
import logging
import requests
import argparse
from time import sleep
from pgoapi import PGoApi
from pgoapi.utilities import f2i, h2f
from pgoapi.location import getNeighbors

from google.protobuf.internal import encoder
from geopy.geocoders import GoogleV3
from s2sphere import CellId, LatLng

log = logging.getLogger(__name__)

def get_pos_by_name(location_name):
    geolocator = GoogleV3()
    loc = geolocator.geocode(location_name)
    return (34, -118, 0.0) # INSERT YOUR LONGITUDE AND LATITUDE AND ALTITUDE HERE
    #return (loc.latitude, loc.longitude, loc.altitude)

def get_cellid(lat, long):
    origin = CellId.from_lat_lng(LatLng.from_degrees(lat, long)).parent(15)
    walk = [origin.id()]

    # 10 before and 10 after
    next = origin.next()
    prev = origin.prev()
    for i in range(10):
        walk.append(prev.id())
        walk.append(next.id())
        next = next.next()
        prev = prev.prev()
    return ''.join(map(encode, sorted(walk)))

def encode(cellid):
    output = []
    encoder._VarintEncoder()(output.append, cellid)
    return ''.join(output)

def init_config():
    parser = argparse.ArgumentParser()
    config_file = "config.json"

    # If config file exists, load variables from json
    load   = {}
    if os.path.isfile(config_file):
        with open(config_file) as data:
            load.update(json.load(data))

    # Read passed in Arguments
    required = lambda x: not x in load['accounts'][0].keys()
    parser.add_argument("-a", "--auth_service", help="Auth Service ('ptc' or 'google')",
        required=required("auth_service"))
    parser.add_argument("-i", "--config_index", help="config_index", required=required("config_index"))
    parser.add_argument("-u", "--username", help="Username", required=required("username"))
    parser.add_argument("-p", "--password", help="Password", required=required("password"))
    parser.add_argument("-l", "--location", help="Location", required=required("location"))
    parser.add_argument("-d", "--debug", help="Debug Mode", action='store_true')
    parser.add_argument("-c", "--cached", help="cached", action='store_true')
    parser.add_argument("-t", "--test", help="Only parse the specified location", action='store_true')
    parser.set_defaults(DEBUG=False, TEST=False,CACHED=False)
    config = parser.parse_args()
    load = load['accounts'][int(config.__dict__['config_index'])]
    # Passed in arguments shoud trump
    for key in config.__dict__:
        if key in load and config.__dict__[key] == None:
            config.__dict__[key] = load[key]

    if config.auth_service not in ['ptc', 'google']:
      log.error("Invalid Auth service specified! ('ptc' or 'google')")
      return None

    return config


def main():
    # log settings
    # log format
    logging.basicConfig(level=logging.DEBUG, format='%(asctime)s [%(module)10s] [%(levelname)5s] %(message)s')
    # log level for http request class
    logging.getLogger("requests").setLevel(logging.WARNING)
    # log level for main pgoapi class
    logging.getLogger("pgoapi").setLevel(logging.INFO)
    # log level for internal pgoapi class
    logging.getLogger("rpc_api").setLevel(logging.INFO)

    config = init_config()
    if not config:
        return

    if config.debug:
        logging.getLogger("requests").setLevel(logging.DEBUG)
        logging.getLogger("pgoapi").setLevel(logging.DEBUG)
        logging.getLogger("rpc_api").setLevel(logging.DEBUG)

    position = get_pos_by_name(config.location)
    if config.test:
        return

    api = PGoApi(CP_CUTOFF=100) # HERE IS THE CP OF THE POKEMON THAT YOU DON'T WANT || CHANGE CP HERE
    # provide player position on the earth
    api.set_position(*position)

    if not api.login(config.auth_service, config.username, config.password, config.cached):
        return

    # chain subrequests (methods) into one RPC call

    # get player profile call
    # ----------------------
    api.get_player()

    # get inventory call
    # ----------------------
    api.get_inventory()

    # get map objects call
    # ----------------------
    #timestamp = "\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000\000"
    #cellid = get_cellid(position[0], position[1])
    #api.get_map_objects(latitude=f2i(position[0]), longitude=f2i(position[1]), since_timestamp_ms=timestamp, cell_id=cellid)

    # spin a fort
    # ----------------------
    #fortid = '<your fortid>'
    #lng = <your longitude>
    #lat = <your latitude>
    #api.fort_search(fort_id=fortid, fort_latitude=lat, fort_longitude=lng, player_latitude=f2i(position[0]), player_longitude=f2i(position[1]))

    # release/transfer a pokemon and get candy for it
    # ----------------------
    api.release_pokemon(pokemon_id = 19)
    api.release_pokemon(pokemon_id = 21)

    # get download settings call
    # ----------------------
    #api.download_settings(hash="4a2e9bc330dae60e7b74fc85b98868ab4700802e")

    # execute the RPC call
    response_dict = api.call()
    print('Response dictionary: \n\r{}'.format(json.dumps(response_dict, indent=2)))
    # r = api.get_player().call()
    # print(r)
    # alternative:
    # api.get_player().get_inventory().get_map_objects().download_settings(hash="4a2e9bc330dae60e7b74fc85b98868ab4700802e").call()
    while True:
        api.main_loop()
        # print("Any pokemon caught? : ", api.catch_near_pokemon())
        # print(api.spin_near_fort())
        # try:
        #     print(api.spin_near_fort())
        # except Exception as e:
        #     print("Something went wrong: ", e)
        #     sleep(30)
    import ipdb; ipdb.set_trace()

if __name__ == '__main__':
    main()
